import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class LoginReg {

    static TestReports TestReport = new TestReports();


    public static WebElement FindElement(WebDriver driver, String Path) throws InterruptedException
    {
        WebElement webElement = driver.findElement(By.xpath(Path));
        return webElement;
    }


    public static void Reg(WebDriver driver , String User , String First , String Last , String Email , String Country , String Password) throws InterruptedException {

        driver.get("http://localhost/opencart/");
        FindElement(driver, "(//i[@class='fa-solid fa-caret-down'])[2]\n").click();
        FindElement(driver, "//a[text()='Register']\n").click();
        FindElement(driver,  "//input[@id=\"input-password\"]").sendKeys(Password);
        FindElement(driver, "//input[@id=\"input-email\"]").sendKeys(Email);
        FindElement(driver, "//input[@id=\"input-firstname\"]").sendKeys(First);
        FindElement(driver, "//input[@id=\"input-lastname\"]").sendKeys(Last);
        FindElement(driver, "//input[@name=\"agree\"]").click();
        FindElement(driver, "//button[@class=\"btn btn-primary\"]").click();
    }

    public static void Log(WebDriver driver , String Email , String Password) throws InterruptedException
    {
        driver.get("http://localhost/opencart/");
        FindElement(driver, "(//i[@class='fa-solid fa-caret-down'])[2]\n").click();
        FindElement(driver, "//a[text()='Login']\n").click();
        FindElement(driver, "//input[@name=\"email\"]").sendKeys(Email);
        FindElement(driver, "//input[@name=\"password\"]").sendKeys(Password);
        FindElement(driver, "//button[@class=\"btn btn-primary\"]").click();
    }

    public static void Tc_001 (WebDriver driver) throws InterruptedException {

        String testName = "TC_001";
        String expected = "http://localhost/opencart/index.php?route=account/success&language=en-gb&customer_token=dec69dad9e5a2f552e36fa8d2b";
        String actual = "";
        String status = "";

        try {

            Reg(driver,"Maryam5489","Maryam","Alaa","Maryam@gmail.com","Egypy","Pass123");


            actual = driver.getCurrentUrl();


            status = actual.contains("http://localhost/opencart/index.php?route=account/success&language=en-gb&customer_token=dec69dad9e5a2f552e36fa8d2b") ? "PASS" : "FAIL";

        } catch (Exception e) {
            status = "FAIL";
            actual = e.getMessage();
        }


        TestReport.add(testName, status, expected, actual);
    }

    public static void Tc_027 (WebDriver driver) throws InterruptedException {

        String testName = "TC_027";
        String expected = "E-Mail Address does not appear to be valid!";
        String actual = "";
        String status = "";

        try {

            Reg(driver,"Maryam5489","Maryam","Alaa","Mar","Egypy","Pass123");


            actual = FindElement(driver, "//div[@class=\"text-danger\"]").getText();


            status = actual.contains("E-Mail Address does not appear to be valid!") ? "PASS" : "FAIL";

        } catch (Exception e) {
            status = "FAIL";
            actual = e.getMessage();
        }


        TestReport.add(testName, status, expected, actual);
    }

    public static void Tc_028 (WebDriver driver) throws InterruptedException {

        String testName = "TC_028";

        //stays in same page
        String expected = "http://localhost/opencart/index.php?route=account/register&language=en-gb";
        String actual = "";
        String status = "";

        try {

            Reg(driver,"","","","","","");

            actual = driver.getCurrentUrl();


            status = actual.contains("http://localhost/opencart/index.php?route=account/register&language=en-gb") ? "PASS" : "FAIL";

        } catch (Exception e) {
            status = "FAIL";
            actual = e.getMessage();
        }


        TestReport.add(testName, status, expected, actual);
    }

    public static void Tc_002 (WebDriver driver) throws InterruptedException {
        String testName = "TC_002";
        String expected = "";
        String actual = "";
        String status = "";

        try {

            Log(driver,"maryamalaa938@gmail.com","maryamalaa2024");
            actual = driver.getCurrentUrl();


            status = actual.contains("") ? "PASS" : "FAIL";

        } catch (Exception e) {
            status = "FAIL";
            actual = e.getMessage();
        }


        TestReport.add(testName, status, expected, actual);

    }

    public static void Tc_003 (WebDriver driver) throws InterruptedException {
        String testName = "TC_003";
        String expected = " No match for E-Mail and/or Password.";
        String actual = "";
        String status = "";

        try {

            Log(driver,"m@gmail.com","98562");
            actual = FindElement(driver, "//div[@class=\"alert alert-danger\"]").getText();


            status = actual.contains("No match for E-Mail and/or Password.") ? "PASS" : "FAIL";

        } catch (Exception e) {
            status = "FAIL";
            actual = e.getMessage();
        }


        TestReport.add(testName, status, expected, actual);

    }

    public static void main(String[] args) throws InterruptedException {


        WebDriver driver = new EdgeDriver();
        driver.manage().window().maximize();

        try {

            // Run each test case
            Tc_001(driver);
            Tc_027(driver);
            Tc_002(driver);
            Tc_003(driver);
            TestReports.print();


            System.out.println(" ALL TESTS COMPLETED!");

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }finally {
            driver.quit();
        }

    }
}