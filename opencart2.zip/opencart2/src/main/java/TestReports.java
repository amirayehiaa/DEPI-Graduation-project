import java.util.ArrayList;
import java.util.List;
public class TestReports {
    static class TestCaseResult {
        String name;
        String status;
        String expected;
        String actual;

        TestCaseResult(String name, String status, String expected, String actual) {
            this.name = name;
            this.status = status;
            this.expected = expected;
            this.actual = actual;
        }
    }

    static List<TestCaseResult> results = new ArrayList<>();

    public static void add(String name, String status, String expected, String actual) {
        results.add(new TestCaseResult(name, status, expected, actual));
    }

    public static void print() {
        System.out.println("\n==================== TEST REPORT ====================\n");
        System.out.printf("%-10s %-6s %-50s %-50s\n", "TestCase", "Status", "Expected URL", "Actual URL");
        System.out.println("---------------------------------------------------------------------------------------------");
        for (TestCaseResult r : results) {
            System.out.printf("%-10s %-6s %-50s %-50s\n", r.name, r.status, r.expected, r.actual);
        }
        System.out.println("\n====================================================\n");
    }
}
