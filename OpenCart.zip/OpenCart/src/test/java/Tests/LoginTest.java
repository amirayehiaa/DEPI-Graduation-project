package Tests;

import BaseTest.BaseTestClass;
import Pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTest extends BaseTestClass {

    LoginPage loginPage;

    @Test
    public void testValidLogin() {

        driver.get(baseUrl + "index.php?route=account/login&language=en-gb");

        loginPage = new LoginPage(driver);


        String validEmail = ConfigReader.getProperty("loginEmail");
        String validPass = ConfigReader.getProperty("loginPassword");

        loginPage.enterEmail(validEmail);
        loginPage.enterPassword(validPass);
        loginPage.clickLogin();

        Assert.assertTrue(driver.getTitle().contains("My Account"), " Login Failed!");
    }
}
