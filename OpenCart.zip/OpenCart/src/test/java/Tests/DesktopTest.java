package Tests;

import BaseTest.BaseTestClass;
import Pages.Desktop.DesktopProduct;
import Pages.Desktop.MacPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class DesktopTest extends BaseTestClass{
    MacPage macPage;
    DesktopProduct desktopProduct;

    @Test
    public void Test(){
        desktopPage=homePage.clickDesktopPage();
        macPage=desktopPage.clickMacPage();
        desktopProduct=macPage.clickDesktopProduct();
        desktopProduct.enterQuantity("2");
        desktopProduct.clickOnAddToCart();
        Assert.assertTrue(desktopProduct.getConfirmationMsg().contains("Success"));

    }
}
