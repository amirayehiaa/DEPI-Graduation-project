package Tests;

import BaseTest.BaseTestClass;
import Pages.RegisterPage;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class RegisterTest extends BaseTestClass {
    RegisterPage registerPage;

    @Test
    public void testUserCanRegisterSuccessfully() {

        driver.get(baseUrl + "index.php?route=account/register&language=en-gb");

        registerPage = new RegisterPage(driver);


        String email = "testuser" + System.currentTimeMillis() + "@test.com";


        registerPage.enterFirstName("Maryam");
        registerPage.enterLastName("Alaa");
        registerPage.enterEmail(email);
        registerPage.enterPassword("12345678");
        registerPage.acceptAgreement();
        registerPage.clickContinue();


        String successMessage = driver.findElement(By.cssSelector("#content h1")).getText();
        Assert.assertEquals("Your Account Has Been Created!", successMessage, "❌ Registration failed!");
    }
}
