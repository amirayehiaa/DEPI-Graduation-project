package Tests;

import BaseTest.BaseTestClass;
import Pages.Component.SearchMenu.Monitor.MonitorPage;
import Pages.Component.SearchMenu.Monitor.MonitorProduct;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class MonitorTest extends BaseTestClass {
    MonitorPage monitorPage;
    MonitorProduct monitorProduct;

    @Test
    public void EnsureCheckbox2IsSelected(){
        componentsPage=homePage.clickComponentPage();
        monitorPage=componentsPage.clickMonitorPage();
        monitorProduct=monitorPage.clickMonitorProduct();
        monitorProduct.enterQuantity("2");
        monitorProduct.enterTextArea("textareaaaa");
        monitorProduct.selectSmall();
        monitorProduct.ClickOnOptionBasedOnIndex(2);
        monitorProduct.selectCheckbox2();
        Assert.assertTrue(monitorProduct.validateCheckbox2isSelected());
        Assert.assertTrue(monitorProduct.EnsureOptionIsSelected(2));
        monitorProduct.clickOnAddToCart();
        Assert.assertTrue(monitorProduct.getConfirmationMsg().contains("Success"));

    }
}
