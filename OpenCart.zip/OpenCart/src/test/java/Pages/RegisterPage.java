package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegisterPage {
    public WebDriver driver;

    private By firstNameField = By.id("input-firstname");
    private By lastNameField  = By.id("input-lastname");
    private By emailField     = By.id("input-email");
    private By passwordField  = By.id("input-password");
    private By agreeCheckbox  = By.name("agree");
    private By continueButton = By.xpath("//button[@type='submit']");

    public RegisterPage(WebDriver driver) {
        this.driver = driver;
    }

    public RegisterPage enterFirstName(String firstName) {
        driver.findElement(firstNameField).clear();
        driver.findElement(firstNameField).sendKeys(firstName);
        return this;
    }

    public RegisterPage enterLastName(String lastName) {
        driver.findElement(lastNameField).clear();
        driver.findElement(lastNameField).sendKeys(lastName);
        return this;
    }

    public RegisterPage enterEmail(String email) {
        driver.findElement(emailField).clear();
        driver.findElement(emailField).sendKeys(email);
        return this;
    }

    public RegisterPage enterPassword(String password) {
        driver.findElement(passwordField).clear();
        driver.findElement(passwordField).sendKeys(password);
        return this;
    }

    public void acceptAgreement() {
        driver.findElement(agreeCheckbox).click();
    }

    public void clickContinue() {
        driver.findElement(continueButton).click();
    }
}
