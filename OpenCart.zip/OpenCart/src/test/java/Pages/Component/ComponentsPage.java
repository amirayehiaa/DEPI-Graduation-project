package Pages.Component;

import Pages.Component.SearchMenu.MiceAndTrackballsPage;
import Pages.Component.SearchMenu.Monitor.MonitorPage;
import Pages.Component.SearchMenu.PrintersPage;
import Pages.Component.SearchMenu.ScannersPage;
import Pages.Component.SearchMenu.WebCamerasPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ComponentsPage {
    WebDriver driver;
    WebDriverWait wait;

    public ComponentsPage(WebDriver driver) {
        this.driver = driver;
        wait=new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    By MiceandTrackballsLinkLocator = By.linkText("Mice and Trackballs (0)");
    By MonitorsLinkLocator=By.linkText("Monitors (2)");
    By PrintersLinkLocator=By.linkText("Printers (0)");
    By ScannersLinkLocator=By.linkText("Scanners (0)");
    By WebCamerasLinkLocator=By.linkText("Web Cameras (0)");
    By AddToCartBtnLinkLocator=By.xpath("(//i[@class='fa-solid fa-shopping-cart'])[1]");
    By AddToWishlistBtnLinkLocator=By.xpath("(//i[@class='fa-solid fa-heart'])[1]");
    By CompareBtnLinkLocator=By.xpath("(//i[@class='fa-solid fa-arrow-right-arrow-left'])[1]");
    By CompareMsgLinkLocator=By.xpath("//div[@class='alert alert-success alert-dismissible']");


    public MiceAndTrackballsPage clickMiceAndTrackballsPage(){
        driver.findElement(MiceandTrackballsLinkLocator).click();
        return new MiceAndTrackballsPage(driver);
    }

    public MonitorPage clickMonitorPage(){
        driver.findElement(MonitorsLinkLocator).click();
        return new MonitorPage(driver);
    }

    public PrintersPage clickPrintersPage(){
        driver.findElement(PrintersLinkLocator).click();
        return new PrintersPage(driver);
    }

    public ScannersPage clickScannersPage(){
        driver.findElement(ScannersLinkLocator).click();
        return new ScannersPage(driver);
    }

    public WebCamerasPage clickWebCamerasPage(){
        driver.findElement(WebCamerasLinkLocator).click();
        return new WebCamerasPage(driver);
    }

    public void clickOnAddToCartBtn(){
        driver.findElement(AddToCartBtnLinkLocator).click();
    }

    public void clickOnAddToWishlist(){
        driver.findElement(AddToWishlistBtnLinkLocator).click();
    }

    public void clickOnCompare(){
        driver.findElement(CompareBtnLinkLocator).click();
    }

    public String getCompareMsg(){
        wait.until(ExpectedConditions.presenceOfElementLocated(CompareMsgLinkLocator)).click();
        return driver.findElement(CompareMsgLinkLocator).getText();
    }

    public String actualRedirectionOfCart(){
        clickOnAddToCartBtn();
        return driver.getCurrentUrl();
    }







}
