package Pages.Component.SearchMenu.Monitor;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class MonitorProduct {
    WebDriver driver;
    WebDriverWait wait;

    public MonitorProduct(WebDriver driver) {
        this.driver = driver;
        wait=new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    By AddToCartBtnLinkLocator = By.xpath("//button[@id='button-cart']");
    By MsgLinkLocator = By.xpath("//div[@id='alert']/div");
    By AddToWishlistBtnLinkLocator = By.xpath("(//i[@class='fa-solid fa-heart'])[1]");
    By CompareBtnLinkLocator = By.xpath("(//i[@class='fa-solid fa-arrow-right-arrow-left'])[1]");
    //selected options
    By SmallRadioLL = By.xpath("(//label[@class='form-check-label']) [1]");
    By MediumRadioLL = By.xpath("(//label[@class='form-check-label']) [2]");
    By LargeRadioLL = By.xpath("(//label[@class='form-check-label']) [3]");
    By CheckBox1LL = By.xpath("(//label[@class='form-check-label']) [4]");
    By CheckBox2LL = By.xpath("(//label[@class='form-check-label']) [5]");
    By CheckBox3LL = By.xpath("(//label[@class='form-check-label']) [6]");
    By CheckBox4LL = By.xpath("(//label[@class='form-check-label']) [7]");

    By TextLL = By.xpath("//input[@id='input-option-208']");
//    By SelectColorLL = By.xpath("//select[@id='input-option-217']");
    By TextAreaLL = By.xpath("//textarea[@id='input-option-209']");
    By DateLl = By.xpath("//input[@id='input-option-219']");
    By TimeLL = By.xpath("//input[@id='input-option-221']");
    By QuantityLL = By.xpath("//input[@id='input-quantity']");
    By ColorOptions=By.cssSelector("select option");



    public void clickOnAddToCart() {
        driver.findElement(AddToCartBtnLinkLocator).click();
    }

    public void clickOnAddToWishlist() {
        driver.findElement(AddToWishlistBtnLinkLocator).click();
    }

    public void clickOnCompare() {
        driver.findElement(CompareBtnLinkLocator).click();
    }

    public String getConfirmationMsg() {                          //all messages has the same link locator
        wait.until(ExpectedConditions.presenceOfElementLocated(MsgLinkLocator)).click();
        return driver.findElement(MsgLinkLocator).getText();
    }

    //available options

    public void selectSmall() {
        driver.findElement(SmallRadioLL).click();
    }

    public void selectMedium() {
        driver.findElement(MediumRadioLL).click();
    }

    public void selectLarge() {
        driver.findElement(LargeRadioLL).click();
    }

    public void selectCheckbox1() {
        driver.findElement(CheckBox1LL).click();
    }

    public void selectCheckbox2() {
        driver.findElement(CheckBox2LL).click();
    }

    public void selectCheckbox3() {
        driver.findElement(CheckBox3LL).click();
    }

    public void selectCheckbox4() {
        driver.findElement(CheckBox4LL).click();
    }
    //validate selection

    public boolean validateCheckbox1isSelected(){
        return driver.findElement(CheckBox1LL).isSelected();
    }
    public boolean validateCheckbox2isSelected(){
        return driver.findElement(CheckBox2LL).isSelected();
    }
    public boolean validateCheckbox3isSelected(){
        return driver.findElement(CheckBox3LL).isSelected();
    }
    public boolean validateCheckbox4isSelected(){
        return driver.findElement(CheckBox4LL).isSelected();
    }

    //send keys
    public void enterText(String text){
        driver.findElement(TextLL).sendKeys(text);
    }

    public void enterTextArea(String text){
        driver.findElement(TextAreaLL).sendKeys(text);
    }

    public void enterDate(String date){
        driver.findElement(DateLl).sendKeys(date);
    }

    public void enterTime(String time){
        driver.findElement(TimeLL).sendKeys(time);
    }

    public void enterQuantity(String num){
        driver.findElement(QuantityLL).sendKeys(num);
    }


    //dropdown
    public void ClickOnOptionBasedOnIndex(int i){
        List<WebElement>option=driver.findElements(ColorOptions);        //index
        option.get(i++).click();
    }

    public boolean EnsureOptionIsSelected(int i){
        List<WebElement>option=driver.findElements(ColorOptions);
        return option.get(i++).isSelected();
    }





}




