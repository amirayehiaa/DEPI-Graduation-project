package Pages.Component.SearchMenu.Monitor;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Test1Page {
    WebDriver driver;

    public Test1Page(WebDriver driver) {
        this.driver = driver;
    }

    By ContinueBtnLinkLocator= By.linkText("Continue");

    public void clickOnContinueBtn(){
        driver.findElement(ContinueBtnLinkLocator).click();
    }

}
