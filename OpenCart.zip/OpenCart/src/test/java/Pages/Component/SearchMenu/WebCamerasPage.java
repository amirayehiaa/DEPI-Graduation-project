package Pages.Component.SearchMenu;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class WebCamerasPage {
    WebDriver driver;

    public WebCamerasPage(WebDriver driver) {
        this.driver = driver;
    }

    By ContinueBtnLinkLocator= By.linkText("Continue");

    public void clickOnContinueBtn(){
        driver.findElement(ContinueBtnLinkLocator).click();
    }

}
