package Pages.MP3Player;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class MP3PlayerProduct {
    WebDriver driver;
    WebDriverWait wait;

    public MP3PlayerProduct(WebDriver driver) {
        this.driver = driver;
        wait=new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    By AddToCartBtnLinkLocator = By.xpath("//button[@id='button-cart']");
    By MsgLinkLocator = By.xpath("//div[@id='alert']/div");
    By AddToWishlistBtnLinkLocator = By.xpath("(//i[@class='fa-solid fa-heart'])[1]");
    By CompareBtnLinkLocator = By.xpath("(//i[@class='fa-solid fa-arrow-right-arrow-left'])[1]");
    By QuantityLL = By.xpath("//input[@id='input-quantity']");



    public void clickOnAddToCart() {
        driver.findElement(AddToCartBtnLinkLocator).click();
    }

    public void clickOnAddToWishlist() {
        driver.findElement(AddToWishlistBtnLinkLocator).click();
    }

    public void clickOnCompare() {
        driver.findElement(CompareBtnLinkLocator).click();
    }

    public String getConfirmationMsg() {                          //all messages has the same link locator
        wait.until(ExpectedConditions.presenceOfElementLocated(MsgLinkLocator)).click();
        return driver.findElement(MsgLinkLocator).getText();
    }

    public void enterQuantity(String num){
        driver.findElement(QuantityLL).sendKeys(num);
    }


}
