package Pages.Software;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SoftwarePage {
    WebDriver driver;

    public SoftwarePage(WebDriver driver) {
        this.driver = driver;
    }

    By ContinueBtnLinkLocator=By.cssSelector("a[class='btn btn-primary']");

    public void clickContinueBtn(){
        driver.findElement(ContinueBtnLinkLocator).click();
    }
}
