package Pages;

import Pages.Camera.CameraPage;
import Pages.Component.ComponentsPage;
import Pages.Desktop.DesktopPage;
import Pages.Laptop.LaptopPage;
import Pages.MP3Player.MP3PlayerPage;
import Pages.Phones.PhonePage;
import Pages.Software.SoftwarePage;
import Pages.Tablets.TabletPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
    WebDriver driver;

    public HomePage(WebDriver driver){
        this.driver=driver;
    }

    By DesktopPageLinkLocator=By.xpath("//a[text()='Desktops']");
    By LaptopsPageLinkLocator=By.xpath("//a[text()='Laptops & Notebooks']");
    By ComponentsPageLinkLocator=By.xpath("//a[text()='Components']");
    By TabletsPageLinkLocator=By.xpath("//a[text()='Tablets']");
    By SoftwarePageLinkLocator=By.xpath("//a[text()='Software']");
    By PhonesPageLinkLocator=By.xpath("//a[text()='Phones & PDAs']");
    By CamerasPageLinkLocator =By.xpath("//a[text()='Cameras']");
    By MP3PlayersPageLinkLocator=By.xpath("//a[text()='MP3 Players']");

    By DesktopPageLinkLocator2=By.linkText("Show All Desktops");
    By LaptopsPageLinkLocator2=By.linkText("Show All Laptops & Notebooks");
    By ComponentsPageLinkLocator2=By.linkText("Show All Components");
    By MP3PlayersPageLinkLocator2=By.linkText("Show All MP3 Players");



    public DesktopPage clickDesktopPage(){
        driver.findElement(DesktopPageLinkLocator).click();
        driver.findElement(DesktopPageLinkLocator2).click();
        return new DesktopPage(driver);
    }
    public LaptopPage clickLaptopPage(){
        driver.findElement(LaptopsPageLinkLocator).click();
        driver.findElement(LaptopsPageLinkLocator2).click();
        return new LaptopPage(driver);
    }
    public ComponentsPage clickComponentPage(){
        driver.findElement(ComponentsPageLinkLocator).click();
        driver.findElement(ComponentsPageLinkLocator2).click();
        return new ComponentsPage(driver);
    }
    public TabletPage clickTabletsPage(){
        driver.findElement(TabletsPageLinkLocator).click();
        return new TabletPage(driver);
    }
    public SoftwarePage clickSoftwarePage(){
        driver.findElement(SoftwarePageLinkLocator).click();
        return new SoftwarePage(driver);
    }
    public PhonePage clickPhonesPage(){
        driver.findElement(PhonesPageLinkLocator).click();
        return new PhonePage(driver);
    }
    public CameraPage clickCamerasPage(){
        driver.findElement(CamerasPageLinkLocator).click();
        return new CameraPage(driver);
    }
    public MP3PlayerPage clickMP3PlayersPage(){
        driver.findElement(MP3PlayersPageLinkLocator).click();
        driver.findElement(MP3PlayersPageLinkLocator2).click();
        return new MP3PlayerPage(driver);
    }

}
