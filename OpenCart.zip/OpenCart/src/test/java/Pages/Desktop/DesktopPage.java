package Pages.Desktop;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class DesktopPage {
    WebDriver driver;
    WebDriverWait wait;

    public DesktopPage(WebDriver driver) {
        this.driver = driver;
        wait=new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    By MacPageLinkLocator=By.linkText("Mac (1)");
    By PCPageLinkLocator=By.linkText("PC (0)");
//    By AddToCartBtnLinkLocator=By.xpath("(//i[@class='fa-solid fa-shopping-cart'])[1]");
//    By AddToWishlistBtnLinkLocator=By.xpath("(//i[@class='fa-solid fa-heart'])[1]");
//    By CompareBtnLinkLocator=By.xpath("(//i[@class='fa-solid fa-arrow-right-arrow-left'])[1]");
//    By MsgLinkLocator = By.xpath("//div[@id='alert']/div");


    public MacPage clickMacPage(){
        driver.findElement(MacPageLinkLocator).click();
        return new MacPage(driver);
    }

    public PCPage clickPCPage(){
        driver.findElement(PCPageLinkLocator).click();
        return new PCPage(driver);
    }



}
