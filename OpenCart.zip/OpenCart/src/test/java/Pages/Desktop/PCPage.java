package Pages.Desktop;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PCPage {
    WebDriver driver;

    public PCPage(WebDriver driver) {
        this.driver = driver;
    }

    By ContinueBtnLinkLocator= By.linkText("Continue");

    public void clickOnContinueBtn(){
        driver.findElement(ContinueBtnLinkLocator).click();
    }
}
