package Pages.Tablets;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class TabletPage {
    WebDriver driver;
    WebDriverWait wait;

    public TabletPage(WebDriver driver) {
        this.driver = driver;
        wait=new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    By TabletProductLinkLocator=By.linkText("Samsung Galaxy Tab 10.1");
    By AddToCartBtnLinkLocator=By.xpath("(//i[@class='fa-solid fa-shopping-cart'])[1]");
    By AddToWishlistBtnLinkLocator=By.xpath("(//i[@class='fa-solid fa-heart'])[1]");
    By CompareBtnLinkLocator=By.xpath("(//i[@class='fa-solid fa-arrow-right-arrow-left'])[1]");
    By MsgLinkLocator = By.xpath("//div[@id='alert']/div");
    public TabletProduct clickTabletProduct(){
        driver.findElement(TabletProductLinkLocator).click();
        return new TabletProduct(driver);
    }

    public void clickOnAddToCartBtn(){
        driver.findElement(AddToCartBtnLinkLocator).click();
    }

    public void clickOnAddToWishlist(){
        driver.findElement(AddToWishlistBtnLinkLocator).click();
    }

    public void clickOnCompare(){
        driver.findElement(CompareBtnLinkLocator).click();
    }

    public String getConfirmationMsg(){
        wait.until(ExpectedConditions.presenceOfElementLocated(MsgLinkLocator)).click();
        return driver.findElement(MsgLinkLocator).getText();
    }


}
