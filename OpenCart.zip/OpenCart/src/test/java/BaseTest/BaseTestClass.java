package BaseTest;

import Pages.*;
import Pages.Camera.CameraPage;
import Pages.Component.ComponentsPage;
import Pages.Desktop.DesktopPage;
import Pages.Laptop.LaptopPage;
import Pages.MP3Player.MP3PlayerPage;
import Pages.Phones.PhonePage;
import Pages.Software.SoftwarePage;
import Pages.Tablets.TabletPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

public class BaseTestClass {
    public WebDriver driver;
    public HomePage homePage;
    public CameraPage cameraPage;
    public DesktopPage desktopPage;
    public ComponentsPage componentsPage;
    public LaptopPage laptopPage;
    public MP3PlayerPage mp3PlayersPage;
    public PhonePage phonePage;
    public SoftwarePage softwarePage;
    public TabletPage tabletPage;
    public String addToCartUrl="";
    public String baseUrl = "http://localhost/opencart//";
    public Contactuspage contactuspage;
    @BeforeClass
    public void setup(){
        driver=new FirefoxDriver();
        driver.manage().window().maximize();
        homePage=new HomePage(driver);
    }
    @BeforeMethod
    public void openhomepage(){
        driver.get("http://localhost/opencart//");
    }
    @AfterClass
    public void teardown(){
        driver.quit();
    }
}
